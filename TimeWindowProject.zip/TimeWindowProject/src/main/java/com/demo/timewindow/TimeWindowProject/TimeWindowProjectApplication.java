package com.demo.timewindow.TimeWindowProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeWindowProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TimeWindowProjectApplication.class, args);
	}
}
