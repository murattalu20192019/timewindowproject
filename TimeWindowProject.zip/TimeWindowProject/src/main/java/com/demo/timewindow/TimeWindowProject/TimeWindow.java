package com.demo.timewindow.TimeWindowProject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

public class TimeWindow {

	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList<Integer>();
		List<Integer> tmp = new ArrayList<Integer>();
		
		Properties prop = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();           
		InputStream stream = loader.getResourceAsStream("application.properties");
		
		try {
			prop.load(stream);
		} catch (IOException exception) {
			exception.printStackTrace();
		}
		
		Random rd = new Random();
		int countWindow = 0;
		int countWindowMinute = 0;
		int countDuration = 0;
		Boolean pauseSleepMinute = false;
		
		int threadSleepTime = 15000; // assuming that every 15 seconds we receive an event or not, 
		Integer MAX_EVENT_AMOUNT = Integer.parseInt((String) prop.get("maxEventAmount"));
		Integer WINDOW_IME = Integer.parseInt((String) prop.get("windowTime"));
		Integer SLEEP_TIME = Integer.parseInt((String) prop.get("sleepTime"));
		
		while(true) {

			if(pauseSleepMinute) {// sleep 
				countDuration++;	
			}
			
			if(countDuration >= SLEEP_TIME/threadSleepTime) { //  awake from sleep
				pauseSleepMinute = false;
				list.addAll(tmp);
				tmp = new ArrayList<Integer>();
			}
			
			if(!pauseSleepMinute) { // event window part
				
				countWindowMinute++;
				rd = new Random();
				int i = rd.nextInt(2);// check there is an event or not
				System.out.println("Event Happened = " + ((i == 0) ? "No" : "Yes"));
				
				if(i == 1) { 
					// We check there is an event or not, if it is 1, 
					//there is an event, generate a new number and store to the list
					int j = rd.nextInt(100);// event value
					tmp.add(j);
					System.out.println("Event Value = " + (j));
					countWindow++;
				}
				
				if(countWindow >= MAX_EVENT_AMOUNT && countWindowMinute >= WINDOW_IME/threadSleepTime) { // check the event amount in window minute
					pauseSleepMinute = true; // if it is more than 10 in 5 minutes, pause 2 minute
					System.out.println(WINDOW_IME/(60*1000) + " Minute completed, " + SLEEP_TIME/(60*1000) + "minute sleep, event amount = " + countWindow);
					countWindowMinute = 0;
					countDuration = 0;
					countWindow = 0;
					list.addAll(tmp);
					System.out.println("List = " + list.toString());
				}else if(countWindowMinute >= WINDOW_IME/threadSleepTime) {
					System.out.println(WINDOW_IME/(60*1000) + " Minute completed, Start Again " + WINDOW_IME/(60*1000) + " Minute Window , event amount = " + countWindow);
					countWindowMinute = 0;
					countWindow = 0;
					list.addAll(tmp);
					tmp = new ArrayList<Integer>();
					System.out.println("List = " + list.toString());
				}
			}
			
			try {
				Thread.sleep(threadSleepTime); // We are assuming that every 15 seconds we know there is an event or not, so sleep 15 seconds to simulate
			} catch (Exception e) {
				e.printStackTrace();
			}
	
		}
			
	}

}
